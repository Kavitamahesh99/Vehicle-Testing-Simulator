"""Run after `cap add android`. Makes the app full-screen (status/nav bars
hidden, draws into the display cutout) so the simulator fills the phone."""
import pathlib, re, sys

styles = pathlib.Path("android/app/src/main/res/values/styles.xml")
if not styles.exists():
    sys.exit("styles.xml not found - run `npx cap add android` first")

xml = styles.read_text()
items = (
    '        <item name="android:windowFullscreen">true</item>\n'
    '        <item name="android:windowLayoutInDisplayCutoutMode">shortEdges</item>\n'
)
if "android:windowFullscreen" in xml:
    print("styles.xml already patched")
else:
    # add to every theme that is NoActionBar-based (main theme + launch/splash theme)
    def add(m):
        return m.group(0).replace("</style>", items + "    </style>")
    xml2 = re.sub(r'<style name="AppTheme\.NoActionBar[^"]*"[^>]*>.*?</style>', add, xml, flags=re.S)
    if xml2 == xml:
        sys.exit("Could not find AppTheme.NoActionBar in styles.xml")
    styles.write_text(xml2)
    print("styles.xml patched: fullscreen + cutout")
