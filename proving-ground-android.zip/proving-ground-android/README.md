# Proving Ground Simulator - Android APK

Game ki file `www/index.html` mein hai (original, bina badle). Baaki sab Android wrapper (Capacitor) hai.

## Tareeka A: Sirf phone se (PC nahi chahiye)
1. github.com pe free account banao, naya **private** repo banao.
2. Is zip ke andar ki saari files repo mein upload karo (Add file > Upload files).
   `.github` folder bhi upload hona chahiye.
3. Repo mein **Actions** tab > **Build Android APK** > **Run workflow**.
4. 5-8 minute baad run khulega, neeche **Artifacts** mein `ProvingGround-debug-apk` download karo.
5. Zip kholo, `app-debug.apk` phone mein install karo ("Install unknown apps" allow karna padega).

## Tareeka B: PC pe
Chahiye: Node 20+, Java 21, Android Studio (SDK ke saath).
```
npm install
npm run prepare:android      # android project + icon + fullscreen patch + sync
npm run open                 # Android Studio khulega > Build > Build APK
```
Ya terminal se: `cd android && ./gradlew assembleDebug`
APK: `android/app/build/outputs/apk/debug/app-debug.apk`

## Dhyan dene wali baatein
- **Fonts:** Barlow Condensed / IBM Plex Mono Google Fonts se aate hain. Internet ke bina system font dikhega (game chalega, bas look thoda alag). Offline ke liye font files `www/` mein daalke index.html ka `<link>` badalna hoga.
- **Saved data:** runs/settings localStorage mein save hote hain, app mein bhi chalenge. App uninstall karne par ud jayenge.
- **Code protection:** APK ek zip hai, koi bhi `assets/public/index.html` nikal sakta hai. Bachav ke liye pehle JS obfuscate karo, phir build.
- **Play Store:** debug APK sirf install/test ke liye hai. Store ke liye signed release (AAB) aur keystore chahiye.
- **Orientation:** abhi auto-rotate hai. Sirf landscape chahiye to bata do, patch add kar dunga.
